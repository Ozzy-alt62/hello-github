﻿namespace hello_github
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, GitHub! Je m'appelle Osman Dirieh");
        }
    }
}
